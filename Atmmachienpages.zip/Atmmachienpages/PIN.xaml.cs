﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atmmachienpages
{
    
    public partial class PIN : Window
    {
        public PIN()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string correctPassword = "1111";  
            if (PasswordInput.Password == correctPassword)
            {
                Homepg homepg = new Homepg();
                homepg.Show();

                this.Close();
            }
            else
            {
                MessageBox.Show("Incorrect PIN! Try Again.", "Access Denied", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            PINChange pIN = new PINChange();
            pIN.Show();
            this.Close();

        }
    }
}