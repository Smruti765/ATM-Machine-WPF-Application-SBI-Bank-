﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atmmachienpages
{
    /// <summary>
    /// Interaction logic for Homepg.xaml
    /// </summary>
    public partial class Homepg : Window
    {
        public Homepg()
        {
            InitializeComponent();
        }

        private void withrow_btn(object sender, RoutedEventArgs e)
        {
            Withdraw withdraw = new Withdraw();
            withdraw.Show();

            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Deposit deposit = new Deposit();
            deposit.Show();

            this.Close();

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            BalanceInquiryxaml balanceInquiryxaml = new BalanceInquiryxaml();
            balanceInquiryxaml.Show();

            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            PINChange pINChange = new PINChange();
            pINChange.Show();

            this.Close();
        }
    }
}
