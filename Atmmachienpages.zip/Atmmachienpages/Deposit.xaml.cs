﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atmmachienpages
{
    
    public partial class Deposit : Window
    {
        public Deposit()
        {
            InitializeComponent();
        }
              

        private void submit_btn(object sender, RoutedEventArgs e)
        {
            int amount;

            if (string.IsNullOrWhiteSpace(txtAmount.Text))
            {
                MessageBox.Show("Please enter an amount before proceeding.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (int.TryParse(txtAmount.Text, out amount))
            {
                MessageBox.Show($"The entered amount is: {amount}");
                Global.amount = amount;
            }
            else
            {
                MessageBox.Show("Invalid input! Please enter a valid number.");
            }

            tnxcomplete tnxcomplete = new tnxcomplete();
            tnxcomplete.Show();
            this.Close();
        }

        private void erase_btn(object sender, RoutedEventArgs e)
        {
            txtAmount.Text = "";

        }
    }
}
