﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atmmachienpages
{
    /// <summary>
    /// Interaction logic for PINChange.xaml
    /// </summary>
    public partial class PINChange : Window
    {
        public PINChange()
        {
            InitializeComponent();
        }

        private void SubmitPinChange(object sender, RoutedEventArgs e)
        {
            PIN pIN = new PIN();
            pIN.Show();
            this.Close();
        }
    }
}
