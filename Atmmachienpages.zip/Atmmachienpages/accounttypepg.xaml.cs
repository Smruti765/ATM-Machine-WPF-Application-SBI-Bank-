﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Atmmachienpages
{
    /// <summary>
    /// Interaction logic for accounttypepg.xaml
    /// </summary>
    public partial class accounttypepg : Window
    {
        public accounttypepg()
        {
            InitializeComponent();
        }

        private void saving_btn(object sender, RoutedEventArgs e)
        {
            PIN pin = new PIN();
            pin.Show();
            this.Close();
        }

        private void current_btn(object sender, RoutedEventArgs e)
        {
            PIN pin = new PIN();
            pin.Show();
            this.Close();
        }

        private void create_card_btn(object sender, RoutedEventArgs e)
        {
            PIN pin = new PIN();
            pin.Show();
            this.Close();

        }
    }
}
