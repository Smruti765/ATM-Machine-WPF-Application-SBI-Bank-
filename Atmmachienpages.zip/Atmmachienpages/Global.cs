﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atmmachienpages
{
    class Global
    {
        public static int amount { get; set; } = 0;
    }
}
